using System;
using System.Collections;
using Combat;
using Inventory;
using UnityEngine;

namespace Stats
{
    public class PlayerStats : MonoBehaviour, ISaveable
    {
        [Header("연동 시스템")]
        public InventorySystem inventory;

        [Header("레벨/경험치")]
        public int level = 1;
        public int exp = 0;
        public int expToLevelUp = 100;

        [Header("Base Stat(최초/강화/레벨업 모두 반영)")]
        private int baseAttack = 5;
        private float baseAtkSpeed = 1.0f;
        private int baseDefense = 0;
        private int baseHp = 1000;
        private float baseCritRate = 0.1f;
        private float baseCritDmg = 1.5f;

        // 캐싱
        public float FinalAttack { get; private set; }
        public float FinalAtkSpeed { get; private set; }
        public float FinalDefense { get; private set; }
        public float FinalHp { get; private set; }
        public float FinalCritRate { get; private set; }
        public float FinalCritDmg { get; private set; }

        // 버프 임시 필드
        public float TempAttackBuff = 0f;
        public float adAttackBuff = 0f;
        public float TempAtkSpeedBuff = 0f;
        public float TempCritRateBuff = 0f;

        // 체력 (예시)
        public float currentHp;

        private void Awake()
        {
            if (!inventory) inventory = GetComponent<InventorySystem>();
            currentHp = baseHp;
        }

        private void Start()
        {
            var save = SaveManager.pendingSaveData;
            if (save != null)
                ApplyLoadedData(save);
            inventory.OnInventoryChanged += RefreshStats;
            RefreshStats();
        }

        public void AddExp(int amount)
        {
            exp += amount;
            while (exp >= expToLevelUp)
            {
                exp -= expToLevelUp;
                LevelUp();
            }
            OnExpChanged?.Invoke();
        }

        void LevelUp()
        {
            level++;
            expToLevelUp += 50;
            baseHp += 5;
            baseAttack += 1;
            baseDefense += 1;
            RefreshStats();
            OnLevelUp?.Invoke(level);
        }

        public void UpgradeAttack(int amount = 1)      { baseAttack += amount; RefreshStats(); }
        public void UpgradeDefense(int amount = 1)     { baseDefense += amount; RefreshStats(); }
        public void UpgradeHp(int amount = 10)         { baseHp += amount; RefreshStats(); }
        public void UpgradeAtkSpeed(float amount = 0.05f) { baseAtkSpeed += amount; RefreshStats(); }
        public void UpgradeCritRate(float amount = 0.01f) { baseCritRate += amount; RefreshStats(); }
        public void UpgradeCritDmg(float amount = 0.05f)  { baseCritDmg += amount; RefreshStats(); }

        public void RefreshStats()
        {
            var (atkMul, atkSpdMul) = inventory.GetWeaponMultipliers();
            adAttackBuff = AdBuffManager.Instance != null && AdBuffManager.Instance.AttackBuffActive ? 1.0f : 0f;
            FinalAttack = Mathf.FloorToInt(baseAttack * atkMul * (1f + TempAttackBuff + adAttackBuff));
            FinalAtkSpeed  = baseAtkSpeed * atkSpdMul * (1f + TempAtkSpeedBuff);

            var (defMul, hpMul) = inventory.GetArmorMultipliers();
            FinalDefense  = Mathf.FloorToInt(baseDefense * defMul);
            FinalHp       = Mathf.FloorToInt(baseHp * hpMul);

            var (critRateMul, critDmgMul) = inventory.GetAccessoryMultipliers();
            FinalCritRate = baseCritRate * critRateMul + TempCritRateBuff;
            FinalCritDmg  = baseCritDmg * critDmgMul;

            // 패시브 스킬(퀵슬롯 장착만 적용) 누적
            var passives = inventory.GetEquippedSkillDataList()
                .FindAll(s => s.skillType == SkillType.Passive);
            foreach (var s in passives)
            {
                if (s.id == "skill_05" && s.OwnedDefPercent > 0f) // 대지의 수호: 방어 20%
                    FinalDefense += FinalDefense * s.OwnedDefPercent;
                else if (s.id == "skill_13")
                {
                    FinalAttack += FinalAttack * s.OwnedAtkPercent;
                    FinalCritRate += s.OwnedCritRatePercent;
                }
                // 기타 패시브도 필요하면 추가
            }
            OnStatsChanged?.Invoke();
        }

        public void ApplyLoadedData(SaveData data)
        {
            if (data == null) return;
            level = data.level;
            exp = data.exp;
            expToLevelUp = data.expToLevelUp;
        }
        public void CollectSaveData(SaveData data)
        {
            data.level = level;
            data.exp = exp;
            data.expToLevelUp = expToLevelUp;
        }

        // ----------- 이벤트들 -------------
        public event Action OnStatsChanged = delegate { };
        public event Action OnExpChanged = delegate { };
        public event Action<int> OnLevelUp = delegate { };

        // ----------- 체력/회복/피해 함수 -------------
        public void Heal(float amount)
        {
            currentHp = Mathf.Min(currentHp + amount, FinalHp);
            Debug.Log($"플레이어 회복: {amount} → 현재 HP {currentHp}/{FinalHp}");
        }
    

        public void ResetAllUpgrades()
        {
            baseAttack = 5;
            baseAtkSpeed = 1.0f;
            baseDefense = 0;
            baseHp = 1000;
            baseCritRate = 0.1f;
            baseCritDmg = 1.5f;
        }
        
        public int CombatPower
        {
            get
            {
                float power =
                    FinalAttack * 2f +
                    FinalDefense * 1.5f +
                    FinalHp * 0.2f +
                    FinalAtkSpeed * 50f +
                    FinalCritRate * 1000f +
                    FinalCritDmg * 200f;
                return Mathf.FloorToInt(power);
            }
        }
    }
}
