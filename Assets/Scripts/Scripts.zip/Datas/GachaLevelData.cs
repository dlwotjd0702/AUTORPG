/*using System.Collections.Generic;


public class GachaLevelInfo
{
    public int level = 1;
    public int exp = 0;
    public Dictionary<int, float> gradeRates = new();
}*/